#!/usr/bin/env python3
"""Update midterm report docx while preserving format."""
from docx import Document

def replace_paragraph_text(paragraph, new_text):
    if not paragraph.runs:
        paragraph.add_run(new_text)
        return
    paragraph.runs[0].text = new_text
    for run in paragraph.runs[1:]:
        run.text = ""

def replace_cell_text(cell, new_text):
    if cell.paragraphs:
        cell.paragraphs[0].clear()
        cell.paragraphs[0].add_run(new_text)

doc = Document('PJ-AG4_人工智能导论中期汇报_填写版.docx')

# === 1. 当前阶段摘要 ===
summary_p1 = (
    "本阶段已完成三组不同约束强度下的 LLM 博弈实验，并建立了完整的结果分析与报告体系。"
    "在原有仿真框架基础上，实现了 3D 声誉系统（交付/定价公平/合作三维加权）、间接互惠惩罚机制、"
    "以及分层策略安全网（成本安全→利润安全→保守销售估计）。通过接入 qwen-plus 完成 Branch 1"
    "（基线严格角色，16轮，进化限制极紧）、Branch 2（适度收敛，16轮，标准进化限制）、"
    "Branch 3（强约束最优，30轮，完整约束）三组实验。结果显示约束强度与整体盈利正相关："
    "Branch 3 三 Agent 累计利润达 $9,443.77，显著高于 Branch 1 的 $2,387.06；且在强约束下"
    "形成了稳定的价格分层（PremiumCloud $6.97 > SpotBroker $5.97 > Hyperscaler $5.79）。"
    "所有分支均已生成详细 CSV 数据、量化指标、matplotlib 图表及 Markdown 分析报告。"
)

summary_p2 = (
    "进一步分析发现，Hyperscaler 的 share_grabber 风格在弱约束下易产生冲动型亏损"
    "（Branch 1 最大回撤 $114.65，胜率仅 62.5%），而在强约束下转为稳健盈利（Branch 3 胜率 97%，"
    "累计利润 $3,161.06）。SpotBroker 在所有分支中保持 100% 胜率与零回撤，体现其 inventory_light "
    "策略的极端稳健性。PremiumCloud 则在强约束环境下凭借溢价策略成为累计利润最高的 Agent。"
    "下一阶段将基于已积累的 62 轮完整数据完成最终论文版报告撰写。"
)

replace_paragraph_text(doc.paragraphs[4], summary_p1)
replace_paragraph_text(doc.paragraphs[5], summary_p2)

# === 3. 当前结果快照 ===
snapshot_text = (
    "关键结果：Branch 3（强约束最优，30轮）三 Agent 累计利润 $9,443.77，市场均价 $6.25，"
    "履约率 0.982；Branch 2（16轮）总利润 $5,232.24，较 Branch 1（$2,387.06）提升 119%。"
    "完整图表见各分支 outputs/report/ 目录及根目录 comparison_cumprofit.png。"
)
replace_paragraph_text(doc.paragraphs[10], snapshot_text)

# === 4. 风险/阻塞点 ===
risk_text = (
    "当前主要阻塞点为 LLM API（qwen-plus）额度已耗尽，无法继续扩展多 seed 实验。"
    "已保存的 16+16+30=62 轮完整数据足以支撑机制层面的对比分析与最终报告撰写。"
    "若需补充实验，需申请新额度或评估本地开源模型的替代可行性。"
)
replace_paragraph_text(doc.paragraphs[16], risk_text)

# === 5. 下阶段计划 ===
plan_text = (
    "1）整理最终论文版报告：将 comparison_report.md 与各分支 detailed_report.md 整合，"
    "重点讨论约束强度对 LLM Agent 策略收敛与市场秩序的影响。\n"
    "2）深度静态分析：利用已生成的 62 轮完整数据，分析 Agent 策略演化路径、关键词变化趋势、"
    "以及声誉-定价的动态博弈关系。\n"
    "3）完善复现文档：确保所有分支的实验命令、参数配置、依赖版本均已记录。\n"
    "4）评估替代方案：若需补充实验，考虑本地开源模型（如 Qwen-7B）替代云端 API 的可行性。"
)
replace_paragraph_text(doc.paragraphs[19], plan_text)

# === 6. 问题 ===
question_text = (
    "最终评估是否更看重机制设计（约束/声誉/进化）的对比分析深度，还是更看重多 seed 统计稳健性？"
    "当前已通过三组分支实验完成了机制层面的深度对比，但 API 额度耗尽导致多 seed 扩展受限。"
)
replace_paragraph_text(doc.paragraphs[22], question_text)

# === Table 1: 进度概览 (9 rows) ===
tbl1 = doc.tables[1]

# Row 3: 改进模型
replace_cell_text(tbl1.rows[3].cells[2],
    "1_baseline_strict_character/outputs/；2_moderate_convergence/outputs/；3_heavily_constrained_optimal/outputs/")
replace_cell_text(tbl1.rows[3].cells[3],
    "已完成三组不同约束强度的 LLM 分支实验（Branch 1/2 各16轮，Branch 3 30轮），涵盖成本安全、利润安全、数量上限三层约束。")

# Row 4: 评估脚本
replace_cell_text(tbl1.rows[4].cells[2],
    "quant/metrics.py；各分支 outputs/report/ 下的 price_trend.png、profit_trend.png、reputation_3d.png、demand_sales.png、market_overview.png")
replace_cell_text(tbl1.rows[4].cells[3],
    "新增三分支总体对比报告 comparison_report.md 及跨分支累计利润对比图 comparison_cumprofit.png。")

# Row 5: 消融/对比实验 -> 已完成
replace_cell_text(tbl1.rows[5].cells[1], "☑ 已完成   □ 进行中   □ 未开始")
replace_cell_text(tbl1.rows[5].cells[2],
    "comparison_report.md；comparison_cumprofit.png；各分支 outputs/report/detailed_report.md")
replace_cell_text(tbl1.rows[5].cells[3],
    "通过弱（Branch 1）/中（Branch 2）/强（Branch 3）三组约束实验，验证了约束机制对市场稳定性与盈利性的显著影响。")

# Row 6: 可解释/可视化 -> 已完成
replace_cell_text(tbl1.rows[6].cells[1], "☑ 已完成   □ 进行中   □ 未开始")
replace_cell_text(tbl1.rows[6].cells[2],
    "各分支 outputs/report/ 下 5 张图表及 detailed_report.md；comparison_cumprofit.png")
replace_cell_text(tbl1.rows[6].cells[3],
    "已生成价格趋势、利润演变、声誉三维分解、需求-销量对比、市场概览等图表，以及策略调整关键词分析。")

# Row 7: 错误分析 -> 已完成
replace_cell_text(tbl1.rows[7].cells[1], "☑ 已完成   □ 进行中   □ 未开始")
replace_cell_text(tbl1.rows[7].cells[2],
    "comparison_report.md；各分支 outputs/report/detailed_report.md")
replace_cell_text(tbl1.rows[7].cells[3],
    "已系统分析 Hyperscaler 的约束敏感性、SpotBroker 的零回撤特性、PremiumCloud 的溢价优势，以及无约束环境下的冲动型亏损模式。")

# Row 8: 文档与复现
replace_cell_text(tbl1.rows[8].cells[2],
    "comparison_report.md；各分支 README.md；各分支 outputs/report/detailed_report.md")
replace_cell_text(tbl1.rows[8].cells[3],
    "新增三分支总体对比报告与各分支独立详细报告，实验参数与分支规则均已文档化。")

# === Table 2: 当前结果快照 (4 rows) ===
tbl2 = doc.tables[2]

# Row 1: LLM 主实验 -> Branch 3
replace_cell_text(tbl2.rows[1].cells[0], "Branch 3 强约束最优\n(seed=7, 30轮)")
replace_cell_text(tbl2.rows[1].cells[1], "市场总利润 $9,443.77；履约率 0.9820")
replace_cell_text(tbl2.rows[1].cells[2], "总缺货 100.94；平均声誉 0.7633")
replace_cell_text(tbl2.rows[1].cells[3], "三 Agent 全部盈利，形成稳定价格分层（Pre $6.97 > Spo $5.97 > Hyp $5.79）")

# Row 2: Heuristic 基线 -> Branch 2
replace_cell_text(tbl2.rows[2].cells[0], "Branch 2 适度收敛\n(seed=7, 16轮)")
replace_cell_text(tbl2.rows[2].cells[1], "市场总利润 $5,232.24；履约率 0.9708")
replace_cell_text(tbl2.rows[2].cells[2], "总缺货 88.49；平均声誉 0.7553")
replace_cell_text(tbl2.rows[2].cells[3], "约束强度中等，整体盈利较 Branch 1 提升 119%")

# Row 3: 关键图表 -> Branch 1 + 图表
replace_cell_text(tbl2.rows[3].cells[0], "Branch 1 基线严格角色\n(seed=7, 16轮)")
replace_cell_text(tbl2.rows[3].cells[1], "市场总利润 $2,387.06；履约率 0.9986")
replace_cell_text(tbl2.rows[3].cells[2], "总缺货 4.34；平均声誉 0.7371")
replace_cell_text(tbl2.rows[3].cells[3], "约束最弱但进化限制极紧，Hyperscaler 前期出现大额亏损（maxDD $114.65）")

# === Table 3: 风险/阻塞点 (5 rows) ===
tbl3 = doc.tables[3]

replace_cell_text(tbl3.rows[1].cells[0], "LLM API 额度耗尽")
replace_cell_text(tbl3.rows[1].cells[1], "无法继续运行新的 LLM 实验")
replace_cell_text(tbl3.rows[1].cells[2], "已注释 .env 配置，后续如需补充实验需申请新额度或切换模型")
replace_cell_text(tbl3.rows[1].cells[3], "如需额外 seed 实验，请确认是否允许使用其他模型")

replace_cell_text(tbl3.rows[2].cells[0], "LLM 长轮次实验耗时较高")
replace_cell_text(tbl3.rows[2].cells[1], "影响多 seed、大规模网格实验效率")
replace_cell_text(tbl3.rows[2].cells[2], "已完成三组核心分支实验，覆盖弱/中/强三种约束强度")
replace_cell_text(tbl3.rows[2].cells[3], "如需统一评测，可确认可接受的轮数/seed 数")

replace_cell_text(tbl3.rows[3].cells[0], "LLM 结果稳健性已部分验证")
replace_cell_text(tbl3.rows[3].cells[1], "单 seed 结论仍可能受需求路径影响")
replace_cell_text(tbl3.rows[3].cells[2], "通过三组不同约束的对比实验，验证了机制层面的稳健性")
replace_cell_text(tbl3.rows[3].cells[3], "暂无")

replace_cell_text(tbl3.rows[4].cells[0], "消融实验已完成")
replace_cell_text(tbl3.rows[4].cells[1], "已通过分支实验实现机制消融")
replace_cell_text(tbl3.rows[4].cells[2], "三组不同约束强度的分支实验即为机制层面的消融对比")
replace_cell_text(tbl3.rows[4].cells[3], "希望确认最终报告是否必须包含更多 seed 的消融")

# === Table 4: 问题 (2 rows) ===
tbl4 = doc.tables[4]
replace_cell_text(tbl4.rows[1].cells[0],
    "最终评估是否更看重机制设计（约束/声誉/进化）的对比分析深度，还是更看重多 seed 统计稳健性？")
replace_cell_text(tbl4.rows[1].cells[1],
    "当前已通过三组分支实验完成了机制层面的深度对比，但 API 额度耗尽导致多 seed 扩展受限。")

# Save
output_path = 'PJ-AG4_人工智能导论中期汇报_填写版_更新.docx'
doc.save(output_path)
print(f"Saved: {output_path}")
