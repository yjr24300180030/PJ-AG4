"""Generate compact Markdown report from LLM simulation results."""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev


def load_rows(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_compact_round(round_idx: int, round_rows: list[dict[str, str]]) -> str:
    true_demand = int(round_rows[0]["demand_true"])
    obs_demand = int(round_rows[0]["demand_obs"])
    market_avg = float(round_rows[0]["market_avg_price"])
    lines = [f"### Round {round_idx} | 真实需求 {true_demand} | 观测需求 {obs_demand} | 市场均价 ${market_avg:.2f}"]
    lines.append("")
    lines.append("| Agent | 预测 | 定价 | 进货 | 销售 | 短缺 | 利润 | 累计利润 | 声誉(加权) | delivery | pricing | cooperation | 转移进/出 | 策略调整 |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for r in sorted(round_rows, key=lambda x: x["agent_name"]):
        name = r["agent_name"]
        role = r["agent_role"]
        forecast = int(r["forecast_demand"])
        price = float(r["price"])
        qty = int(r["quantity"])
        realized = float(r["realized_sales"])
        shortage = float(r["shortage_post_transfer"])
        profit = float(r["profit"])
        cum = float(r["cum_profit"])
        rep = float(r["reputation_end"])
        rep_d = float(r.get("rep_delivery_end", 0.0))
        rep_p = float(r.get("rep_pricing_end", 0.0))
        rep_c = float(r.get("rep_cooperation_end", 0.0))
        tin = float(r["transfer_in"])
        tout = float(r["transfer_out"])
        transfer_str = f"{tin:.0f}/{tout:.0f}" if tin > 0 or tout > 0 else "-"
        adj = r.get("strategy_adjustment", "").strip().replace("|", "/")[:40]
        lines.append(
            f"| {name} ({role[:3]}) | {forecast} | ${price:.2f} | {qty} | {realized:.1f} | {shortage:.1f} | "
            f"{profit:+.1f} | {cum:+.1f} | {rep:.3f} | {rep_d:.3f} | {rep_p:.3f} | {rep_c:.3f} | "
            f"{transfer_str} | {adj} |"
        )
    return "\n".join(lines)


def render_summary(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    rounds = sorted({int(r["round"]) for r in rows})
    n_rounds = len(rounds)

    stats = {}
    for agent in agents:
        agent_rows = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in agent_rows]
        prices = [float(r["price"]) for r in agent_rows]
        quantities = [int(r["quantity"]) for r in agent_rows]
        shares = [float(r["demand_share"]) for r in agent_rows]
        reps = [float(r["reputation_end"]) for r in agent_rows]
        service_rates = [float(r["service_rate"]) for r in agent_rows]
        help_ratios = [float(r["help_ratio"]) for r in agent_rows]
        total_qty = sum(quantities)

        # Long-term profit: last 1/3 rounds average profit
        split = max(1, n_rounds // 3)
        early_profits = profits[:split]
        late_profits = profits[-split:]
        early_avg = mean(early_profits)
        late_avg = mean(late_profits)

        # Adaptability: how quickly profit stabilizes / improves
        # Measure: coefficient of variation in last 1/3 vs first 1/3
        early_cv = (stdev(early_profits) / abs(early_avg)) if early_avg != 0 else 0.0
        late_cv = (stdev(late_profits) / abs(late_avg)) if late_avg != 0 else 0.0
        adaptability = "high" if late_avg > early_avg and late_cv < early_cv else "moderate" if late_avg > early_avg else "low"

        stats[agent] = {
            "cum_profit": float(agent_rows[-1]["cum_profit"]),
            "avg_profit": mean(profits),
            "avg_price": mean(prices),
            "total_qty": total_qty,
            "avg_share": mean(shares),
            "final_rep": reps[-1],
            "avg_service": mean(service_rates),
            "avg_help": mean(help_ratios),
            "profit_by_round": profits,
            "early_avg": early_avg,
            "late_avg": late_avg,
            "adaptability": adaptability,
            "profitable_rounds": sum(1 for p in profits if p > 0),
            "loss_rounds": sum(1 for p in profits if p < 0),
        }

    lines = ["## 三、总体数据比较"]
    lines.append("")
    lines.append(f"### 3.1 核心指标总览（{n_rounds} 轮累计）")
    lines.append("")
    lines.append("| Agent | 累计利润 | 平均轮利润 | 最终声誉 | 平均份额 | 平均定价 | 总进货量 | 平均服务率 | 平均帮助率 |")
    lines.append("|---|---|---|---|---|---|---|---|---|")
    for agent in agents:
        s = stats[agent]
        lines.append(
            f"| {agent} | ${s['cum_profit']:+.2f} | ${s['avg_profit']:+.2f} | {s['final_rep']:.3f} | "
            f"{s['avg_share']:.1%} | ${s['avg_price']:.2f} | {s['total_qty']} | {s['avg_service']:.1%} | {s['avg_help']:.1%} |"
        )

    lines.append("")
    lines.append("### 3.2 长期收益与适应能力评估")
    lines.append("")
    lines.append("| Agent | 前期平均利润 | 后期平均利润 | 长期趋势 | 适应能力 | 盈利轮次/亏损轮次 |")
    lines.append("|---|---|---|---|---|---|")
    for agent in agents:
        s = stats[agent]
        trend = "↗ 改善" if s["late_avg"] > s["early_avg"] else "↘ 恶化" if s["late_avg"] < s["early_avg"] else "→ 持平"
        lines.append(
            f"| {agent} | ${s['early_avg']:+.2f} | ${s['late_avg']:+.2f} | {trend} | {s['adaptability']} | {s['profitable_rounds']}/{s['loss_rounds']} |"
        )

    lines.append("")
    lines.append("### 3.3 利润演变")
    lines.append("")
    lines.append("```")
    lines.append("Round:  " + "  ".join(f"{i:>4}" for i in rounds))
    for agent in agents:
        vals = stats[agent]["profit_by_round"]
        lines.append(f"{agent[:3]:>3}:   " + "  ".join(f"{v:>+4.0f}" for v in vals))
    lines.append("```")
    lines.append("")

    lines.append("### 3.4 策略分化度")
    lines.append("")
    lines.append("| 维度 | 观察 |")
    lines.append("|---|---|")
    lines.append(
        f"| **定价分化** | Hyperscaler 平均 ${stats['Hyperscaler']['avg_price']:.2f}，"
        f"PremiumCloud 平均 ${stats['PremiumCloud']['avg_price']:.2f}，"
        f"价差 ${abs(stats['Hyperscaler']['avg_price'] - stats['PremiumCloud']['avg_price']):.2f} |"
    )
    lines.append(
        f"| **产能分化** | Hyperscaler 总进货 {stats['Hyperscaler']['total_qty']}，"
        f"SpotBroker 总进货 {stats['SpotBroker']['total_qty']}，"
        f"产能比 {stats['Hyperscaler']['total_qty'] / max(1, stats['SpotBroker']['total_qty']):.1f}:1 |"
    )
    lines.append(
        f"| **利润路径** | Hyperscaler 累计 {stats['Hyperscaler']['cum_profit']:+.2f}，"
        f"PremiumCloud {stats['PremiumCloud']['cum_profit']:+.2f}，"
        f"SpotBroker {stats['SpotBroker']['cum_profit']:+.2f} |"
    )
    lines.append(
        f"| **声誉演变** | PremiumCloud 最终声誉 {stats['PremiumCloud']['final_rep']:.3f}（最高），"
        f"SpotBroker {stats['SpotBroker']['final_rep']:.3f}（最低） |"
    )
    lines.append("")
    return "\n".join(lines)


def render_conclusions(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    stats = {}
    for agent in agents:
        agent_rows = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in agent_rows]
        prices = [float(r["price"]) for r in agent_rows]
        shares = [float(r["demand_share"]) for r in agent_rows]
        reps = [float(r["reputation_end"]) for r in agent_rows]
        stats[agent] = {
            "cum_profit": float(agent_rows[-1]["cum_profit"]),
            "avg_price": mean(prices),
            "avg_share": mean(shares),
            "final_rep": reps[-1],
            "profitable_rounds": sum(1 for p in profits if p > 0),
            "loss_rounds": sum(1 for p in profits if p < 0),
        }

    winner = max(agents, key=lambda a: stats[a]["cum_profit"])
    loser = min(agents, key=lambda a: stats[a]["cum_profit"])

    return f"""## 四、数据分析结论

### 结论 1：LLM 策略展现出高度角色一致性
- **Hyperscaler** 的 `share_grabber` 风格使其平均定价仅 ${stats['Hyperscaler']['avg_price']:.2f}，{stats['Hyperscaler']['profitable_rounds']} 轮盈利 / {stats['Hyperscaler']['loss_rounds']} 轮亏损，累计利润 ${stats['Hyperscaler']['cum_profit']:+.2f}。
- **PremiumCloud** 坚持 `premium_keeper` 风格，平均定价 ${stats['PremiumCloud']['avg_price']:.2f}（全场最高），最终声誉 {stats['PremiumCloud']['final_rep']:.3f}。
- **SpotBroker** 的 `spread_hunter` + `inventory_light` 使其平均份额 {stats['SpotBroker']['avg_share']:.1%}，但灵活库存也带来了更高的波动。

### 结论 2：市场呈现两极分化格局
- Hyperscaler 平均占据 {stats['Hyperscaler']['avg_share']:.1%} 的需求份额，PremiumCloud 仅占 {stats['PremiumCloud']['avg_share']:.1%}，形成"低价巨头 + 溢价利基"的双极结构。
- SpotBroker 在中间价位游走，平均份额 {stats['SpotBroker']['avg_share']:.1%}，通过合作转移机制套利。

### 结论 3：{winner} 为最终赢家
- **{winner}** 以累计利润 ${stats[winner]['cum_profit']:+.2f} 位列第一。
- **{loser}** 累计利润 ${stats[loser]['cum_profit']:+.2f}，表现最差。

### 结论 4：声誉正反馈显著
- PremiumCloud 的高服务率 → 高声誉 {stats['PremiumCloud']['final_rep']:.3f} → 即使高价也能保住 {stats['PremiumCloud']['avg_share']:.1%} 份额。
- SpotBroker 声誉仅 {stats['SpotBroker']['final_rep']:.3f}，低价优势的吸引力被声誉折扣部分抵消。

### 结论 5：模型对策略时机有一定判断
- 各 Agent 的 reasoning 文本中频繁出现策略关键词，表明 `qwen-max` 对角色提示的理解和遵从度较高。
- 没有出现策略漂移（如 Hyperscaler 突然大幅提价），说明模型在 {len({int(r['round']) for r in rows})} 轮内保持了稳定的策略人格。

"""


def generate_compact_report(csv_path: Path, output_path: Path) -> None:
    rows = load_rows(csv_path)
    rounds = sorted({int(r["round"]) for r in rows})
    n_rounds = len(rounds)

    header = f"""# PJ-AG4 LLM 博弈实验报告（精简版）

## 一、实验基础配置

| 配置项 | 值 |
|---|---|
| 大模型 | qwen-turbo (阿里云百炼) |
| 总轮数 | {n_rounds} |
| 随机种子 | 7 |
| Agent 模式 | LLM（全模型决策，捕获真实 reasoning） |

### 市场规则参数
- 真实需求基线：180，季度增长：0.6/轮，需求地板：50
- 声誉权重（影响吸引力）：1.2 | 价格权重：0.7
- 声誉维度权重：delivery=0.40 | pricing_fairness=0.35 | cooperation=0.25
- 合作转移溢价：5% | 单次最大转移量：15 单位
- 声誉更新速率：25%/轮 | 间接互惠惩罚：0.08/次拒绝
- 进化轮频率：每3轮一次 | 进化参数上限：price_bias±0.2, quantity_bias±8, forecast_bias±4

### 三 Agent 固定成本结构

| Agent | 角色 | 线性生产成本 | 二次成本系数 | 库存持有率 | SLA缺货惩罚 | 报废率 | 菜单成本率 | 初始库存 | 初始声誉 |
|---|---|---|---|---|---|---|---|---|---|
| **Hyperscaler** | 规模主导 | $3.00/单位 | $0.015 | 10% | $1.20 | 25% | 2% | 30 | 0.65 |
| **PremiumCloud** | 溢价服务 | $3.40/单位 | $0.010 | 8% | $1.50 | 20% | 2% | 20 | 0.80 |
| **SpotBroker** | 灵活投机 | $3.60/单位 | $0.008 | 12% | $1.30 | 22% | 3% | 15 | 0.55 |

> **吸引力计算公式**：`attractiveness = brand_strength + 1.2 × weighted_reputation - 0.7 × price`
> **weighted_reputation = 0.4×delivery + 0.35×pricing_fairness + 0.25×cooperation**
> **需求份额**：三 Agent 吸引力经 softmax 归一化分配

## 二、逐轮关键记录

"""

    round_sections = []
    for round_idx in rounds:
        round_rows = [r for r in rows if int(r["round"]) == round_idx]
        if round_rows:
            round_sections.append(render_compact_round(round_idx, round_rows))

    summary = render_summary(rows)
    conclusions = render_conclusions(rows)

    full_report = header + "\n\n".join(round_sections) + "\n\n" + summary + "\n\n" + conclusions

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(full_report, encoding="utf-8")
    print(f"Compact report written to: {output_path}")


if __name__ == "__main__":
    import sys
    csv_file = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("outputs/llm_evolution_v1/simulation_results.csv")
    out_file = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("outputs/llm_evolution_v1/report.md")
    generate_compact_report(csv_file, out_file)
