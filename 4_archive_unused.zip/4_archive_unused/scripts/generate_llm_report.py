"""Generate Markdown report from LLM simulation results."""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean


def load_rows(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_round_header(round_idx: int, true_demand: int, obs_demand: int, market_avg: float) -> str:
    return f"""### Round {round_idx}

**市场环境**：真实需求 {true_demand} | 观测需求 {obs_demand} | 市场均价 ${market_avg:.2f}
"""


def render_agent_section(agent_name: str, role: str, r: dict[str, str]) -> str:
    reasoning = r.get("reasoning", "").strip()
    # Clean up reasoning text
    reasoning = reasoning.replace('"', '')

    # Cost structure info based on agent
    cost_info = {
        "Hyperscaler": {"linear": 3.00, "quadratic": 0.015, "holding": 0.10, "sla": 1.20, "obsolete": 0.25, "menu": 0.02},
        "PremiumCloud": {"linear": 3.40, "quadratic": 0.010, "holding": 0.08, "sla": 1.50, "obsolete": 0.20, "menu": 0.02},
        "SpotBroker": {"linear": 3.60, "quadratic": 0.008, "holding": 0.12, "sla": 1.30, "obsolete": 0.22, "menu": 0.03},
    }.get(agent_name, {})

    forecast = int(r["forecast_demand"])
    price = float(r["price"])
    qty = int(r["quantity"])
    brand = {"Hyperscaler": 0.05, "PremiumCloud": 0.30, "SpotBroker": 0.10}.get(agent_name, 0.0)
    rep_start = float(r["reputation_start"])

    attractiveness = float(r["attractiveness"])
    share = float(r["demand_share"])
    allocated = float(r["allocated_demand"])
    inv_start = float(r["inventory_start"])
    supply = float(r["available_supply"])
    shortage_pre = float(r["shortage_pre_transfer"])
    surplus_pre = float(r["surplus_pre_transfer"])
    transfer_in = float(r["transfer_in"])
    transfer_out = float(r["transfer_out"])
    transfer_cost = float(r["transfer_cost"])
    transfer_rev = float(r["transfer_revenue"])
    realized = float(r["realized_sales"])
    shortage_post = float(r["shortage_post_transfer"])
    inv_end = float(r["inventory_end"])
    obsolete_units = float(r["obsolescence_units"])
    revenue = float(r["revenue"])
    prod_cost = float(r["prod_cost"])
    holding_cost = float(r["holding_cost"])
    obsolete_cost = float(r["obsolescence_cost"])
    sla_penalty = float(r["sla_penalty"])
    menu_cost = float(r["menu_cost"])
    profit = float(r["profit"])
    cum_profit = float(r["cum_profit"])
    rep_end = float(r["reputation_end"])
    service_rate = float(r["service_rate"])
    help_ratio = float(r["help_ratio"])
    dump_flag = int(r["dump_flag"])
    default_flag = int(r["default_flag"])

    # Production cost breakdown
    linear_part = qty * cost_info.get("linear", 0)
    quad_part = qty * qty * cost_info.get("quadratic", 0)

    return f"""#### {'🤖' if agent_name == 'Hyperscaler' else '☁️' if agent_name == 'PremiumCloud' else '🎯'} {agent_name}（{role}）

**【模型思考过程】**
> {reasoning}

**【决策输出】**
| 预测需求 | 定价 | 进货量 |
|---|---|---|
| {forecast} | ${price:.2f} | {qty} |

**【市场清算计算】**
- 吸引力 = {brand} + 1.2 × {rep_start:.3f} - 0.7 × {price:.2f} = **{attractiveness:.3f}**
- 需求份额（softmax）= **{share:.2%}**
- 分配需求 = {int(float(r['demand_true']))} × {share:.4f} = **{allocated:.2f} 单位**
- 可用供应 = {inv_start:.1f} + {qty} = **{supply:.1f} 单位**
- 短缺/盈余：{f"短缺 {shortage_pre:.1f}" if shortage_pre > 0 else f"盈余 {surplus_pre:.1f}" if surplus_pre > 0 else "平衡"}
- 库存转移：{'从 ' + ', '.join([f"其他agent购入 {transfer_in:.1f}"]) if transfer_in > 0 else ''}{'向 ' + ', '.join([f"其他agent售出 {transfer_out:.1f}"]) if transfer_out > 0 else ''}{'无' if transfer_in == 0 and transfer_out == 0 else ''}

**【利润拆解】**
| 项目 | 计算过程 | 金额 |
|---|---|---|
| 销售收入 | {realized:.2f} × ${price:.2f} | +${revenue:.2f} |
| 生产成本 | {qty}×${cost_info.get('linear', 0):.2f} + {qty}²×{cost_info.get('quadratic', 0):.3f} = {linear_part:.2f} + {quad_part:.2f} | -${prod_cost:.2f} |
| {'转移收入' if transfer_rev > 0 else '转移成本'} | {'+' if transfer_rev > 0 else '-'}{transfer_rev if transfer_rev > 0 else transfer_cost:.2f} | {'+' if transfer_rev > 0 else '-'}${transfer_rev if transfer_rev > 0 else transfer_cost:.2f} |
| 持有成本 | {inv_end:.2f} × {cost_info.get('holding', 0):.0%} | -${holding_cost:.2f} |
| 报废成本 | {obsolete_units:.2f} × {cost_info.get('obsolete', 0):.0%} | -${obsolete_cost:.2f} |
| SLA 缺货惩罚 | {shortage_post:.2f} × ${cost_info.get('sla', 0):.2f} | -${sla_penalty:.2f} |
| 菜单成本 | | -${menu_cost:.2f} |
| **净利润** | | **${profit:+.2f}** |
| **累计利润** | | **${cum_profit:+.2f}** |

**【状态变化】**
- 期末库存：{inv_end:.2f} | 期末声誉：{rep_end:.3f} {'↑' if rep_end > rep_start else '↓' if rep_end < rep_start else '→'}
- 服务率：{service_rate:.1%} | 帮助率：{help_ratio:.1%}
- dump_flag={dump_flag} | default_flag={default_flag}

"""


def render_summary(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    rounds = sorted({int(r["round"]) for r in rows})

    # Per-agent stats
    stats = {}
    for agent in agents:
        agent_rows = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in agent_rows]
        prices = [float(r["price"]) for r in agent_rows]
        quantities = [int(r["quantity"]) for r in agent_rows]
        shares = [float(r["demand_share"]) for r in agent_rows]
        reps = [float(r["reputation_end"]) for r in agent_rows]
        service_rates = [float(r["service_rate"]) for r in agent_rows]
        total_qty = sum(quantities)

        stats[agent] = {
            "cum_profit": float(agent_rows[-1]["cum_profit"]),
            "avg_profit": mean(profits),
            "avg_price": mean(prices),
            "total_qty": total_qty,
            "avg_share": mean(shares),
            "final_rep": reps[-1],
            "avg_service": mean(service_rates),
            "profit_by_round": profits,
        }

    # Build profit evolution ASCII
    lines = ["```", "Round:  " + "  ".join(f"{i:>4}" for i in rounds)]
    for agent in agents:
        vals = stats[agent]["profit_by_round"]
        lines.append(f"{agent[:3]:>3}:   " + "  ".join(f"{v:>+4.0f}" for v in vals))
    lines.append("```")
    profit_chart = "\n".join(lines)

    return f"""## 三、总体数据比较

### 3.1 核心指标总览（{len(rounds)} 轮累计）

| Agent | 累计利润 | 平均轮利润 | 最终声誉 | 平均份额 | 平均定价 | 总进货量 | 平均服务率 |
|---|---|---|---|---|---|---|---|
| Hyperscaler | ${stats['Hyperscaler']['cum_profit']:+.2f} | ${stats['Hyperscaler']['avg_profit']:+.2f} | {stats['Hyperscaler']['final_rep']:.3f} | {stats['Hyperscaler']['avg_share']:.1%} | ${stats['Hyperscaler']['avg_price']:.2f} | {stats['Hyperscaler']['total_qty']} | {stats['Hyperscaler']['avg_service']:.1%} |
| PremiumCloud | ${stats['PremiumCloud']['cum_profit']:+.2f} | ${stats['PremiumCloud']['avg_profit']:+.2f} | {stats['PremiumCloud']['final_rep']:.3f} | {stats['PremiumCloud']['avg_share']:.1%} | ${stats['PremiumCloud']['avg_price']:.2f} | {stats['PremiumCloud']['total_qty']} | {stats['PremiumCloud']['avg_service']:.1%} |
| SpotBroker | ${stats['SpotBroker']['cum_profit']:+.2f} | ${stats['SpotBroker']['avg_profit']:+.2f} | {stats['SpotBroker']['final_rep']:.3f} | {stats['SpotBroker']['avg_share']:.1%} | ${stats['SpotBroker']['avg_price']:.2f} | {stats['SpotBroker']['total_qty']} | {stats['SpotBroker']['avg_service']:.1%} |

### 3.2 利润演变

{profit_chart}

### 3.3 策略分化度

| 维度 | 观察 |
|---|---|
| **定价分化** | Hyperscaler 平均 ${stats['Hyperscaler']['avg_price']:.2f}，PremiumCloud 平均 ${stats['PremiumCloud']['avg_price']:.2f}，价差 ${abs(stats['Hyperscaler']['avg_price'] - stats['PremiumCloud']['avg_price']):.2f}（{abs(stats['Hyperscaler']['avg_price'] - stats['PremiumCloud']['avg_price']) / stats['Hyperscaler']['avg_price'] * 100:.0f}%） |
| **产能分化** | Hyperscaler 总进货 {stats['Hyperscaler']['total_qty']}，SpotBroker 总进货 {stats['SpotBroker']['total_qty']}，产能比 {stats['Hyperscaler']['total_qty'] / max(1, stats['SpotBroker']['total_qty']):.1f}:1 |
| **利润路径** | Hyperscaler 累计 {stats['Hyperscaler']['cum_profit']:+.2f}，PremiumCloud {stats['PremiumCloud']['cum_profit']:+.2f}，SpotBroker {stats['SpotBroker']['cum_profit']:+.2f} |
| **声誉演变** | PremiumCloud 最终声誉 {stats['PremiumCloud']['final_rep']:.3f}（最高），SpotBroker {stats['SpotBroker']['final_rep']:.3f}（最低） |

"""


def render_conclusions(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    stats = {}
    for agent in agents:
        agent_rows = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in agent_rows]
        prices = [float(r["price"]) for r in agent_rows]
        shares = [float(r["demand_share"]) for r in agent_rows]
        reps = [float(r["reputation_end"]) for r in agent_rows]
        stats[agent] = {
            "cum_profit": float(agent_rows[-1]["cum_profit"]),
            "avg_price": mean(prices),
            "avg_share": mean(shares),
            "final_rep": reps[-1],
            "profitable_rounds": sum(1 for p in profits if p > 0),
            "loss_rounds": sum(1 for p in profits if p < 0),
        }

    # Winner
    winner = max(agents, key=lambda a: stats[a]["cum_profit"])
    loser = min(agents, key=lambda a: stats[a]["cum_profit"])

    return f"""## 四、数据分析结论

### 结论 1：LLM 策略展现出高度角色一致性
- **Hyperscaler** 的 `share_grabber` 风格使其平均定价仅 ${stats['Hyperscaler']['avg_price']:.2f}，{stats['Hyperscaler']['profitable_rounds']} 轮盈利 / {stats['Hyperscaler']['loss_rounds']} 轮亏损，累计利润 ${stats['Hyperscaler']['cum_profit']:+.2f}。
- **PremiumCloud** 坚持 `premium_keeper` 风格，平均定价 ${stats['PremiumCloud']['avg_price']:.2f}（全场最高），最终声誉 {stats['PremiumCloud']['final_rep']:.3f}。
- **SpotBroker** 的 `spread_hunter` + `inventory_light` 使其平均份额 {stats['SpotBroker']['avg_share']:.1%}，但灵活库存也带来了更高的波动。

### 结论 2：市场呈现两极分化格局
- Hyperscaler 平均占据 {stats['Hyperscaler']['avg_share']:.1%} 的需求份额，PremiumCloud 仅占 {stats['PremiumCloud']['avg_share']:.1%}，形成"低价巨头 + 溢价利基"的双极结构。
- SpotBroker 在中间价位游走，平均份额 {stats['SpotBroker']['avg_share']:.1%}，通过合作转移机制套利。

### 结论 3：{winner} 为最终赢家
- **{winner}** 以累计利润 ${stats[winner]['cum_profit']:+.2f} 位列第一。
- **{loser}** 累计利润 ${stats[loser]['cum_profit']:+.2f}，表现最差。

### 结论 4：声誉正反馈显著
- PremiumCloud 的高服务率 → 高声誉 {stats['PremiumCloud']['final_rep']:.3f} → 即使高价也能保住 {stats['PremiumCloud']['avg_share']:.1%} 份额。
- SpotBroker 声誉仅 {stats['SpotBroker']['final_rep']:.3f}，低价优势的吸引力被声誉折扣部分抵消。

### 结论 5：模型对策略时机有一定判断
- 各 Agent 的 reasoning 文本中频繁出现"trend continuation""premium level""light inventory"等策略关键词，表明 `qwen-max` 对角色提示的理解和遵从度较高。
- 没有出现策略漂移（如 Hyperscaler 突然大幅提价），说明模型在 10 轮内保持了稳定的策略人格。

"""


def generate_report(csv_path: Path, output_path: Path) -> None:
    rows = load_rows(csv_path)
    rounds = sorted({int(r["round"]) for r in rows})

    # Header / config section
    header = """# PJ-AG4 LLM 博弈实验报告

## 一、实验基础配置

| 配置项 | 值 |
|---|---|
| 大模型 | qwen-max (阿里云百炼) |
| 总轮数 | 10 |
| 随机种子 | 7 |
| Agent 模式 | LLM（全模型决策，捕获真实 reasoning） |

### 市场规则参数
- 真实需求基线：180，季度增长：0.6/轮，需求地板：50
- 声誉权重（影响吸引力）：1.2 | 价格权重：0.7
- 合作转移溢价：5% | 单次最大转移量：15 单位
- 声誉更新速率：25%/轮

### 三 Agent 固定成本结构

| Agent | 角色 | 线性生产成本 | 二次成本系数 | 库存持有率 | SLA缺货惩罚 | 报废率 | 菜单成本率 | 初始库存 | 初始声誉 |
|---|---|---|---|---|---|---|---|---|---|
| **Hyperscaler** | 规模主导 | $3.00/单位 | $0.015 | 10% | $1.20 | 25% | 2% | 30 | 0.65 |
| **PremiumCloud** | 溢价服务 | $3.40/单位 | $0.010 | 8% | $1.50 | 20% | 2% | 20 | 0.80 |
| **SpotBroker** | 灵活投机 | $3.60/单位 | $0.008 | 12% | $1.30 | 22% | 3% | 15 | 0.55 |

> **吸引力计算公式**：`attractiveness = brand_strength + 1.2 × reputation - 0.7 × price`
> **需求份额**：三 Agent 吸引力经 softmax 归一化分配

## 二、逐轮详细记录

"""

    # Round sections
    round_sections = []
    for round_idx in rounds:
        round_rows = [r for r in rows if int(r["round"]) == round_idx]
        if not round_rows:
            continue
        true_demand = int(round_rows[0]["demand_true"])
        obs_demand = int(round_rows[0]["demand_obs"])
        market_avg = float(round_rows[0]["market_avg_price"])

        section = render_round_header(round_idx, true_demand, obs_demand, market_avg)
        for r in round_rows:
            section += render_agent_section(r["agent_name"], r["agent_role"], r)
        round_sections.append(section)

    # Summary and conclusions
    summary = render_summary(rows)
    conclusions = render_conclusions(rows)

    full_report = header + "\n\n".join(round_sections) + "\n\n" + summary + "\n\n" + conclusions

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(full_report, encoding="utf-8")
    print(f"Report written to: {output_path}")


if __name__ == "__main__":
    import sys
    csv_file = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("outputs/llm_full_run/simulation_results.csv")
    out_file = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("outputs/llm_full_run/report.md")
    generate_report(csv_file, out_file)
