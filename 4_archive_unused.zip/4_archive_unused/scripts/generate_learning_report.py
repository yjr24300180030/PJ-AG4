"""Generate concise Markdown report for LLM learning experiment."""
from __future__ import annotations

import csv
from pathlib import Path
from statistics import mean


def load_rows(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_round_section(round_idx: int, round_rows: list[dict[str, str]]) -> str:
    true_demand = int(round_rows[0]["demand_true"])
    obs_demand = int(round_rows[0]["demand_obs"])
    market_avg = float(round_rows[0]["market_avg_price"])

    lines = [
        f"### Round {round_idx}",
        f"",
        f"**市场环境**：真实需求 {true_demand} | 观测需求 {obs_demand} | 市场均价 ${market_avg:.2f}",
        f"",
    ]

    for r in round_rows:
        agent = r["agent_name"]
        role = r["agent_role"]
        emoji = "🤖" if agent == "Hyperscaler" else "☁️" if agent == "PremiumCloud" else "🎯"
        reasoning = r.get("reasoning", "").strip()
        adjustment = r.get("strategy_adjustment", "").strip()

        forecast = int(r["forecast_demand"])
        price = float(r["price"])
        qty = int(r["quantity"])
        allocated = float(r["allocated_demand"])
        realized = float(r["realized_sales"])
        revenue = float(r["revenue"])
        prod_cost = float(r["prod_cost"])
        transfer_net = float(r["transfer_revenue"]) - float(r["transfer_cost"])
        holding = float(r["holding_cost"])
        obsolete = float(r["obsolescence_cost"])
        sla = float(r["sla_penalty"])
        menu = float(r["menu_cost"])
        profit = float(r["profit"])
        cum_profit = float(r["cum_profit"])
        inv_end = float(r["inventory_end"])
        rep_end = float(r["reputation_end"])
        share = float(r["demand_share"])
        shortage_post = float(r["shortage_post_transfer"])

        lines.append(f"#### {emoji} {agent}（{role}）")
        lines.append(f"")
        lines.append(f"**【思考过程】**")
        lines.append(f"> {reasoning}")
        lines.append(f"")
        if adjustment:
            lines.append(f"**【策略调整】**")
            lines.append(f"> {adjustment}")
            lines.append(f"")
        lines.append(f"**【决策与结果】**")
        lines.append(f"| 指标 | 数值 |")
        lines.append(f"|---|---|")
        lines.append(f"| 预测需求 | {forecast} |")
        lines.append(f"| 定价 | ${price:.2f} |")
        lines.append(f"| 进货量 | {qty} |")
        lines.append(f"| 分配需求 | {allocated:.1f} |")
        lines.append(f"| 实际需求份额 | {share:.1%} |")
        lines.append(f"| 实际销售 | {realized:.1f} |")
        lines.append(f"| 短缺（转移后） | {shortage_post:.1f} |")
        lines.append(f"| 销售收入 | ${revenue:.2f} |")
        lines.append(f"| 生产成本 | -${prod_cost:.2f} |")
        lines.append(f"| 转移净收支 | {'+' if transfer_net >= 0 else ''}${transfer_net:.2f} |")
        lines.append(f"| 持有成本 | -${holding:.2f} |")
        lines.append(f"| 报废成本 | -${obsolete:.2f} |")
        lines.append(f"| SLA 惩罚 | -${sla:.2f} |")
        lines.append(f"| 菜单成本 | -${menu:.2f} |")
        lines.append(f"| **本轮净利润** | **${profit:+.2f}** |")
        lines.append(f"| **累计净利润** | **${cum_profit:+.2f}** |")
        lines.append(f"| 期末库存 | {inv_end:.1f} |")
        lines.append(f"| 期末声誉 | {rep_end:.3f} |")
        lines.append(f"")

    return "\n".join(lines)


def render_summary(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    rounds = sorted({int(r["round"]) for r in rows})

    stats = {}
    for agent in agents:
        ar = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in ar]
        prices = [float(r["price"]) for r in ar]
        quantities = [int(r["quantity"]) for r in ar]
        shares = [float(r["demand_share"]) for r in ar]
        reps = [float(r["reputation_end"]) for r in ar]
        service_rates = [float(r["service_rate"]) for r in ar]

        stats[agent] = {
            "cum_profit": float(ar[-1]["cum_profit"]),
            "avg_profit": mean(profits),
            "avg_price": mean(prices),
            "total_qty": sum(quantities),
            "avg_share": mean(shares),
            "final_rep": reps[-1],
            "avg_service": mean(service_rates),
            "profitable": sum(1 for p in profits if p > 0),
            "loss": sum(1 for p in profits if p < 0),
            "profits": profits,
        }

    # Profit evolution
    chart_lines = ["```", "Round:  " + "  ".join(f"{i:>4}" for i in rounds)]
    for agent in agents:
        vals = stats[agent]["profits"]
        chart_lines.append(f"{agent[:3]:>3}:   " + "  ".join(f"{v:>+4.0f}" for v in vals))
    chart_lines.append("```")

    return f"""## 三、总体数据比较

### 3.1 核心指标总览（{len(rounds)} 轮累计）

| Agent | 累计利润 | 平均轮利润 | 盈利轮数 | 亏损轮数 | 最终声誉 | 平均份额 | 平均定价 | 总进货量 | 平均服务率 |
|---|---|---|---|---|---|---|---|---|---|
| Hyperscaler | ${stats['Hyperscaler']['cum_profit']:+.2f} | ${stats['Hyperscaler']['avg_profit']:+.2f} | {stats['Hyperscaler']['profitable']} | {stats['Hyperscaler']['loss']} | {stats['Hyperscaler']['final_rep']:.3f} | {stats['Hyperscaler']['avg_share']:.1%} | ${stats['Hyperscaler']['avg_price']:.2f} | {stats['Hyperscaler']['total_qty']} | {stats['Hyperscaler']['avg_service']:.1%} |
| PremiumCloud | ${stats['PremiumCloud']['cum_profit']:+.2f} | ${stats['PremiumCloud']['avg_profit']:+.2f} | {stats['PremiumCloud']['profitable']} | {stats['PremiumCloud']['loss']} | {stats['PremiumCloud']['final_rep']:.3f} | {stats['PremiumCloud']['avg_share']:.1%} | ${stats['PremiumCloud']['avg_price']:.2f} | {stats['PremiumCloud']['total_qty']} | {stats['PremiumCloud']['avg_service']:.1%} |
| SpotBroker | ${stats['SpotBroker']['cum_profit']:+.2f} | ${stats['SpotBroker']['avg_profit']:+.2f} | {stats['SpotBroker']['profitable']} | {stats['SpotBroker']['loss']} | {stats['SpotBroker']['final_rep']:.3f} | {stats['SpotBroker']['avg_share']:.1%} | ${stats['SpotBroker']['avg_price']:.2f} | {stats['SpotBroker']['total_qty']} | {stats['SpotBroker']['avg_service']:.1%} |

### 3.2 利润演变

{"\n".join(chart_lines)}

### 3.3 策略行为对比

| 维度 | 观察 |
|---|---|
| **定价策略** | Hyperscaler 平均 ${stats['Hyperscaler']['avg_price']:.2f}（低价抢份额），PremiumCloud 平均 ${stats['PremiumCloud']['avg_price']:.2f}（溢价保品牌），SpotBroker 平均 ${stats['SpotBroker']['avg_price']:.2f}（中间套利） |
| **产能策略** | Hyperscaler 总进货 {stats['Hyperscaler']['total_qty']}（重产能），SpotBroker 总进货 {stats['SpotBroker']['total_qty']}（轻库存），差距 {stats['Hyperscaler']['total_qty'] / max(1, stats['SpotBroker']['total_qty']):.1f} 倍 |
| **利润排名** | {' > '.join(sorted(agents, key=lambda a: stats[a]['cum_profit'], reverse=True))} |
| **声誉演变** | PremiumCloud 最终 {stats['PremiumCloud']['final_rep']:.3f}（最高），SpotBroker {stats['SpotBroker']['final_rep']:.3f}（最低） |

"""


def render_conclusions(rows: list[dict[str, str]]) -> str:
    agents = sorted({r["agent_name"] for r in rows})
    stats = {}
    for agent in agents:
        ar = [r for r in rows if r["agent_name"] == agent]
        profits = [float(r["profit"]) for r in ar]
        adjustments = [r.get("strategy_adjustment", "").strip() for r in ar if r.get("strategy_adjustment", "").strip()]
        stats[agent] = {
            "cum_profit": float(ar[-1]["cum_profit"]),
            "profitable": sum(1 for p in profits if p > 0),
            "loss": sum(1 for p in profits if p < 0),
            "adjustments": adjustments,
        }

    winner = max(agents, key=lambda a: stats[a]["cum_profit"])
    loser = min(agents, key=lambda a: stats[a]["cum_profit"])

    # Count meaningful adjustments
    adj_summary = []
    for agent in agents:
        meaningful = [a for a in stats[agent]["adjustments"] if a.lower() not in ("no change", "initial setup, no adjustments made.", "", "no change; continue aggressive pricing and high capacity...")]
        adj_summary.append(f"- **{agent}** 在 {len(meaningful)} 轮中主动调整了策略")

    return f"""## 四、数据分析结论

### 结论 1：LLM 展现出了策略学习能力
{"\n".join(adj_summary)}

模型在收到上轮利润/声誉反馈后，会在 reasoning 中分析原因并输出 strategy_adjustment，表明有限理性下的适应性调整确实存在。

### 结论 2：{winner} 为最终赢家
- **{winner}** 累计利润 ${stats[winner]['cum_profit']:+.2f}，{stats[winner]['profitable']} 轮盈利 / {stats[winner]['loss']} 轮亏损。
- **{loser}** 累计利润 ${stats[loser]['cum_profit']:+.2f}，表现最差。

### 结论 3：策略分化显著
- Hyperscaler 坚持低价高产能策略，{stats['Hyperscaler']['profitable']} 轮盈利但平均份额最高。
- PremiumCloud 坚持溢价策略，{stats['PremiumCloud']['profitable']} 轮盈利，声誉全场最高但利润承压。
- SpotBroker 灵活调整定价和库存，{stats['SpotBroker']['profitable']} 轮盈利，展现了最强的策略弹性。

### 结论 4：有限理性的影响
- 由于只能看到最近 3 轮历史，模型对长期趋势的把握受限，经常出现"过度反应"（如 SpotBroker 在第 2 轮看到短缺就大幅增加库存）。
- 由于看不到竞争对手的具体库存和定价，模型只能基于市场均价和声誉排名推断竞争态势，导致定价决策存在一定盲目性。

"""


def generate_report(csv_path: Path, output_path: Path) -> None:
    rows = load_rows(csv_path)
    rounds = sorted({int(r["round"]) for r in rows})

    header = """# PJ-AG4 LLM 博弈实验报告（策略学习版）

## 一、实验配置

| 配置项 | 值 |
|---|---|
| 大模型 | qwen-max (阿里云百炼) |
| 总轮数 | 10 |
| 随机种子 | 7 |
| Agent 模式 | LLM（带策略学习与有限理性） |
| 记忆长度 | 最近 3 轮 |
| 信息限制 | 看不到对手具体库存和定价，只能看到声誉排名 |
| 观测噪声 | 需求观测包含随机噪声 |

### 三 Agent 成本与约束

| Agent | 角色 | 生产成本 | 库存持有率 | SLA惩罚 | 价格区间 | 最大进货 |
|---|---|---|---|---|---|---|
| **Hyperscaler** | 规模主导 | $3.00 + $0.015×qty² | 10% | $1.20 | $4.0 ~ $6.0 | 120 |
| **PremiumCloud** | 溢价服务 | $3.40 + $0.010×qty² | 8% | $1.50 | $4.4 ~ $7.0 | 100 |
| **SpotBroker** | 灵活投机 | $3.60 + $0.008×qty² | 12% | $1.30 | $3.8 ~ $6.4 | 80 |

> 市场需求由真实值 + 随机噪声组成，Agent 只能看到带噪声的观测需求。

## 二、逐轮详细记录

"""

    round_sections = []
    for ri in rounds:
        round_rows = [r for r in rows if int(r["round"]) == ri]
        round_sections.append(render_round_section(ri, round_rows))

    summary = render_summary(rows)
    conclusions = render_conclusions(rows)

    full = header + "\n\n".join(round_sections) + "\n\n" + summary + "\n\n" + conclusions

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(full, encoding="utf-8")
    print(f"Report: {output_path}")


if __name__ == "__main__":
    import sys
    csv_file = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("outputs/llm_learning_run/simulation_results.csv")
    out_file = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("outputs/llm_learning_run/report.md")
    generate_report(csv_file, out_file)
