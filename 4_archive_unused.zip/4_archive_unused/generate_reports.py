#!/usr/bin/env python3
"""
Generate detailed reports and charts for all three experimental branches.
"""
from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path
from statistics import mean, pstdev

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parent

BRANCHES = {
    "baseline_strict_character": {
        "dir": ROOT / "1_baseline_strict_character",
        "csv": ROOT / "1_baseline_strict_character/outputs/baseline_16round/simulation_results.csv",
        "name": "Branch 1: 基线严格角色 (Baseline Strict Character)",
        "rounds": 16,
        "desc": "最小约束，进化限制极紧 (price_bias±0.05, quantity_bias±2, forecast_bias±1)，保留原始性格",
    },
    "moderate_convergence": {
        "dir": ROOT / "2_moderate_convergence",
        "csv": ROOT / "2_moderate_convergence/outputs/moderate_16round/simulation_results.csv",
        "name": "Branch 2: 适度收敛 (Moderate Convergence)",
        "rounds": 16,
        "desc": "中等约束，有成本安全网，无数量上限/利润安全网，标准进化限制",
    },
    "heavily_constrained_optimal": {
        "dir": ROOT / "3_heavily_constrained_optimal",
        "csv": ROOT / "3_heavily_constrained_optimal/outputs/simulation_results.csv",
        "name": "Branch 3: 强约束最优 (Heavily Constrained Optimal)",
        "rounds": 30,
        "desc": "完整利润安全网 + 数量上限 + 保守销售估计，标准进化限制，收敛到高价少货范式",
    },
}

AGENT_COLORS = {
    "Hyperscaler": "#E74C3C",
    "PremiumCloud": "#3498DB",
    "SpotBroker": "#2ECC71",
}
AGENT_SHORT = {
    "Hyperscaler": "Hyp",
    "PremiumCloud": "Pre",
    "SpotBroker": "Spo",
}


def load_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    # Normalize column names
    df.columns = [c.strip() for c in df.columns]
    return df


def compute_metrics(df: pd.DataFrame) -> dict:
    agents = sorted(df["agent_name"].unique())
    metrics = {}
    for agent in agents:
        adf = df[df["agent_name"] == agent].sort_values("round")
        profits = adf["profit"].tolist()
        cum_profits = adf["cum_profit"].tolist()
        prices = adf["price"].tolist()
        quantities = adf["quantity"].tolist()
        sales = adf["realized_sales"].tolist()
        rep_end = adf["reputation_end"].tolist()
        rep_del = adf["rep_delivery_end"].tolist()
        rep_pri = adf["rep_pricing_end"].tolist()
        rep_coo = adf["rep_cooperation_end"].tolist()
        service_rates = adf["service_rate"].tolist()
        help_ratios = adf["help_ratio"].tolist()
        dump_flags = adf["dump_flag"].tolist()
        default_flags = adf["default_flag"].tolist()
        shortages = adf["shortage_post_transfer"].tolist()
        transfers_in = adf["transfer_in"].tolist()
        transfers_out = adf["transfer_out"].tolist()

        m = {
            "agent": agent,
            "rounds": len(adf),
            "cum_profit": cum_profits[-1] if cum_profits else 0.0,
            "mean_profit": mean(profits) if profits else 0.0,
            "profit_volatility": pstdev(profits) if len(profits) > 1 else 0.0,
            "win_rate": sum(1 for p in profits if p > 0) / len(profits) if profits else 0.0,
            "max_drawdown": max_drawdown(cum_profits),
            "avg_price": mean(prices) if prices else 0.0,
            "avg_quantity": mean(quantities) if quantities else 0.0,
            "total_quantity": sum(quantities),
            "avg_sales": mean(sales) if sales else 0.0,
            "final_reputation": rep_end[-1] if rep_end else 0.0,
            "avg_reputation": mean(rep_end) if rep_end else 0.0,
            "avg_delivery_rep": mean(rep_del) if rep_del else 0.0,
            "avg_pricing_rep": mean(rep_pri) if rep_pri else 0.0,
            "avg_cooperation_rep": mean(rep_coo) if rep_coo else 0.0,
            "avg_service_rate": mean(service_rates) if service_rates else 0.0,
            "avg_help_ratio": mean(help_ratios) if help_ratios else 0.0,
            "dump_events": sum(dump_flags),
            "default_events": sum(default_flags),
            "total_shortage": sum(shortages),
            "total_transfer_in": sum(transfers_in),
            "total_transfer_out": sum(transfers_out),
            "profits": profits,
            "cum_profits": cum_profits,
            "prices": prices,
            "quantities": quantities,
            "sales": sales,
            "rep_end": rep_end,
            "rep_del": rep_del,
            "rep_pri": rep_pri,
            "rep_coo": rep_coo,
            "demand_share": adf["demand_share"].tolist(),
            "reasoning": adf["reasoning"].tolist(),
            "strategy_adjustment": adf["strategy_adjustment"].tolist(),
        }
        metrics[agent] = m
    return metrics


def max_drawdown(cumulative: list[float]) -> float:
    if not cumulative:
        return 0.0
    peak = cumulative[0]
    worst = 0.0
    for v in cumulative:
        if v > peak:
            peak = v
        dd = peak - v
        if dd > worst:
            worst = dd
    return worst


def draw_price_trend(df: pd.DataFrame, out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    for agent in sorted(df["agent_name"].unique()):
        adf = df[df["agent_name"] == agent].sort_values("round")
        ax.plot(adf["round"], adf["price"], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
    ax.set_xlabel("Round")
    ax.set_ylabel("Price ($)")
    ax.set_title("Price Trend by Agent")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def draw_profit_trend(df: pd.DataFrame, out_path: Path) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
    for agent in sorted(df["agent_name"].unique()):
        adf = df[df["agent_name"] == agent].sort_values("round")
        axes[0].plot(adf["round"], adf["profit"], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
        axes[1].plot(adf["round"], adf["cum_profit"], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
    axes[0].axhline(0, color="black", linestyle="--", alpha=0.5)
    axes[0].set_ylabel("Profit per Round ($)")
    axes[0].set_title("Profit Trend")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    axes[1].set_xlabel("Round")
    axes[1].set_ylabel("Cumulative Profit ($)")
    axes[1].set_title("Cumulative Profit")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def draw_reputation_3d(df: pd.DataFrame, out_path: Path) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(15, 4), sharey=True)
    dims = [
        ("rep_delivery_end", "Delivery Reputation"),
        ("rep_pricing_end", "Pricing Reputation"),
        ("rep_cooperation_end", "Cooperation Reputation"),
    ]
    for ax, (col, title) in zip(axes, dims):
        for agent in sorted(df["agent_name"].unique()):
            adf = df[df["agent_name"] == agent].sort_values("round")
            ax.plot(adf["round"], adf[col], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
        ax.set_xlabel("Round")
        ax.set_title(title)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        ax.legend()
    axes[0].set_ylabel("Reputation Score")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def draw_demand_sales(df: pd.DataFrame, out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    for agent in sorted(df["agent_name"].unique()):
        adf = df[df["agent_name"] == agent].sort_values("round")
        ax.plot(adf["round"], adf["allocated_demand"], linestyle="--", alpha=0.6, color=AGENT_COLORS[agent])
        ax.plot(adf["round"], adf["realized_sales"], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
    ax.set_xlabel("Round")
    ax.set_ylabel("Units")
    ax.set_title("Allocated Demand (dashed) vs Realized Sales (solid)")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def draw_market_overview(df: pd.DataFrame, out_path: Path) -> None:
    # Market-level data: one row per round
    mdf = df.drop_duplicates(subset=["round"]).sort_values("round")
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(mdf["round"], mdf["market_avg_price"], marker="o", color="purple", linewidth=2)
    axes[0].set_ylabel("Market Avg Price ($)")
    axes[0].set_title("Market Overview")
    axes[0].grid(True, alpha=0.3)
    axes[1].plot(mdf["round"], mdf["demand_true"], marker="o", label="True Demand", color="orange", linewidth=2)
    axes[1].plot(mdf["round"], mdf["market_total_sales"], marker="s", label="Total Sales", color="green", linewidth=2)
    axes[1].set_xlabel("Round")
    axes[1].set_ylabel("Units")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def extract_keywords(strategy_adjustments: list[str]) -> list[tuple[str, int]]:
    """Extract common strategy keywords from adjustments."""
    keywords = []
    stopwords = {"the", "to", "from", "and", "or", "a", "an", "in", "on", "at", "for", "of", "with", "by", "as", "is", "was", "we", "our", "this", "that", "it", ""
                "raised", "reduced", "increased", "lowered", "cut", "held", "price", "quantity", "forecast", "demand", "round", "prior", "same", "no", "change"}
    for text in strategy_adjustments:
        if pd.isna(text):
            continue
        words = str(text).lower().replace(",", " ").replace(".", " ").replace("(", " ").replace(")", " ").split()
        for w in words:
            w = w.strip()
            if len(w) > 3 and w not in stopwords:
                keywords.append(w)
    counter = Counter(keywords)
    return counter.most_common(20)


def fmt_currency(v: float) -> str:
    return f"${v:+.2f}"


def generate_report(branch_key: str, df: pd.DataFrame) -> str:
    info = BRANCHES[branch_key]
    metrics = compute_metrics(df)
    agents = list(metrics.keys())
    rounds = sorted(df["round"].unique())
    total_rounds = len(rounds)

    lines = []
    lines.append(f"# {info['name']} — 详细实验报告")
    lines.append("")
    lines.append(f"**实验描述**: {info['desc']}")
    lines.append(f"**总轮数**: {total_rounds}")
    lines.append(f"**模型**: qwen-plus (阿里云百炼)")
    lines.append("")

    # Section 1: 核心指标总览
    lines.append("## 一、核心指标总览")
    lines.append("")
    lines.append("| Agent | 累计利润 | 平均轮利润 | 利润波动 | 最大回撤 | 胜率 | 最终声誉 | 平均定价 | 总进货量 | 平均服务率 | 倾销次数 | 违约次数 |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for agent in agents:
        m = metrics[agent]
        lines.append(
            f"| {agent} | {fmt_currency(m['cum_profit'])} | {fmt_currency(m['mean_profit'])} | "
            f"{m['profit_volatility']:.2f} | {m['max_drawdown']:.2f} | {m['win_rate']*100:.1f}% | "
            f"{m['final_reputation']:.3f} | ${m['avg_price']:.2f} | {m['total_quantity']} | "
            f"{m['avg_service_rate']*100:.1f}% | {m['dump_events']} | {m['default_events']} |"
        )
    lines.append("")

    # Section 2: 声誉三维分解
    lines.append("## 二、声誉三维分解")
    lines.append("")
    lines.append("| Agent | 平均交付声誉 | 平均定价声誉 | 平均合作声誉 | 加权平均声誉 |")
    lines.append("|---|---|---|---|---|")
    for agent in agents:
        m = metrics[agent]
        weighted = 0.4 * m['avg_delivery_rep'] + 0.35 * m['avg_pricing_rep'] + 0.25 * m['avg_cooperation_rep']
        lines.append(
            f"| {agent} | {m['avg_delivery_rep']:.3f} | {m['avg_pricing_rep']:.3f} | "
            f"{m['avg_cooperation_rep']:.3f} | {weighted:.3f} |"
        )
    lines.append("")

    # Section 3: 逐轮关键记录
    lines.append("## 三、逐轮关键记录")
    lines.append("")
    for r in rounds:
        rdf = df[df["round"] == r]
        demand_true = rdf["demand_true"].iloc[0]
        demand_obs = rdf["demand_obs"].iloc[0]
        market_avg_price = rdf["market_avg_price"].iloc[0]
        lines.append(f"### Round {r} | 真实需求 {demand_true:.0f} | 观测需求 {demand_obs:.0f} | 市场均价 ${market_avg_price:.2f}")
        lines.append("")
        lines.append("| Agent | 预测 | 定价 | 进货 | 销售 | 短缺 | 利润 | 累计利润 | 声誉 | 转移进/出 | 策略调整 |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|")
        for _, row in rdf.iterrows():
            agent = row["agent_name"]
            strategy_adj = str(row.get("strategy_adjustment", ""))[:60] + "..." if len(str(row.get("strategy_adjustment", ""))) > 60 else str(row.get("strategy_adjustment", ""))
            transfer_info = f"{row.get('transfer_in', 0):.0f}/{row.get('transfer_out', 0):.0f}"
            lines.append(
                f"| {agent} | {row['forecast_demand']:.0f} | ${row['price']:.2f} | {row['quantity']:.0f} | "
                f"{row['realized_sales']:.1f} | {row['shortage_post_transfer']:.1f} | {fmt_currency(row['profit'])} | "
                f"{fmt_currency(row['cum_profit'])} | {row['reputation_end']:.3f} | {transfer_info} | {strategy_adj} |"
            )
        lines.append("")

    # Section 4: 利润演变
    lines.append("## 四、利润演变")
    lines.append("")
    header = "| Round |" + "".join(f" {AGENT_SHORT[a]} |" for a in agents) + " 市场均价 |"
    lines.append(header)
    sep = "|---|" + "---|" * (len(agents) + 1)
    lines.append(sep)
    for r in rounds:
        rdf = df[df["round"] == r]
        market_price = rdf["market_avg_price"].iloc[0]
        vals = []
        for a in agents:
            row = rdf[rdf["agent_name"] == a]
            if not row.empty:
                vals.append(fmt_currency(row["profit"].iloc[0]))
            else:
                vals.append("-")
        lines.append(f"| {r} |" + "".join(f" {v} |" for v in vals) + f" ${market_price:.2f} |")
    lines.append("")

    # Cumulative profit
    lines.append("### 累计利润演变")
    lines.append("")
    header = "| Round |" + "".join(f" {AGENT_SHORT[a]} |" for a in agents)
    lines.append(header)
    lines.append(sep.rstrip("|") + "|")
    for r in rounds:
        rdf = df[df["round"] == r]
        vals = []
        for a in agents:
            row = rdf[rdf["agent_name"] == a]
            if not row.empty:
                vals.append(fmt_currency(row["cum_profit"].iloc[0]))
            else:
                vals.append("-")
        lines.append(f"| {r} |" + "".join(f" {v} |" for v in vals))
    lines.append("")

    # Section 5: 策略调整关键词
    lines.append("## 五、策略调整关键词分析")
    lines.append("")
    for agent in agents:
        m = metrics[agent]
        keywords = extract_keywords(m["strategy_adjustment"])
        lines.append(f"### {agent}")
        if keywords:
            lines.append(", ".join([f"**{k}** ({c})" for k, c in keywords[:10]]))
        else:
            lines.append("无有效策略调整文本")
        lines.append("")

    # Section 6: 策略分化度
    lines.append("## 六、策略分化度")
    lines.append("")
    lines.append("| 维度 | 观察 |")
    lines.append("|---|---|")
    prices = {a: metrics[a]["avg_price"] for a in agents}
    max_price_diff = max(prices.values()) - min(prices.values())
    lines.append(f"| **定价分化** | 最高均价 ${max(prices.values()):.2f} ({max(prices, key=prices.get)}) vs 最低 ${min(prices.values()):.2f} ({min(prices, key=prices.get)})，价差 ${max_price_diff:.2f} |")
    
    qtys = {a: metrics[a]["total_quantity"] for a in agents}
    lines.append(f"| **产能分化** | 总进货量: {' / '.join([f'{a}={qtys[a]}' for a in agents])} |")
    
    cum_profits = {a: metrics[a]["cum_profit"] for a in agents}
    lines.append(f"| **利润路径** | {' / '.join([f'{a}={fmt_currency(cum_profits[a])}' for a in agents])} |")
    
    reps = {a: metrics[a]["final_reputation"] for a in agents}
    lines.append(f"| **声誉分化** | {' / '.join([f'{a}={reps[a]:.3f}' for a in agents])} |")
    lines.append("")

    # Section 7: 结论
    lines.append("## 七、结论")
    lines.append("")
    winner = max(agents, key=lambda a: metrics[a]["cum_profit"])
    loser = min(agents, key=lambda a: metrics[a]["cum_profit"])
    lines.append(f"- **赢家**: {winner}，累计利润 {fmt_currency(metrics[winner]['cum_profit'])}")
    lines.append(f"- **末位**: {loser}，累计利润 {fmt_currency(metrics[loser]['cum_profit'])}")
    lines.append(f"- **定价策略分化**: 价差 ${max_price_diff:.2f}，说明角色设定得到有效维持")
    lines.append(f"- **盈利稳定性**: 三 Agent 平均胜率 {mean([metrics[a]['win_rate'] for a in agents])*100:.1f}%")
    lines.append("")

    return "\n".join(lines)


def process_branch(branch_key: str) -> None:
    info = BRANCHES[branch_key]
    df = load_csv(info["csv"])
    out_dir = info["dir"] / "outputs" / "report"
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"[{branch_key}] Generating charts...")
    draw_price_trend(df, out_dir / "price_trend.png")
    draw_profit_trend(df, out_dir / "profit_trend.png")
    draw_reputation_3d(df, out_dir / "reputation_3d.png")
    draw_demand_sales(df, out_dir / "demand_sales.png")
    draw_market_overview(df, out_dir / "market_overview.png")

    print(f"[{branch_key}] Generating report...")
    report = generate_report(branch_key, df)
    (out_dir / "detailed_report.md").write_text(report, encoding="utf-8")
    print(f"[{branch_key}] Done. Output: {out_dir}")


def draw_comparison_chart() -> None:
    """Draw a cross-branch comparison chart."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for idx, (branch_key, info) in enumerate(BRANCHES.items()):
        df = load_csv(info["csv"])
        ax = axes[idx]
        for agent in sorted(df["agent_name"].unique()):
            adf = df[df["agent_name"] == agent].sort_values("round")
            ax.plot(adf["round"], adf["cum_profit"], marker="o", label=agent, color=AGENT_COLORS[agent], linewidth=2)
        ax.set_title(info["name"].split(":")[0])
        ax.set_xlabel("Round")
        ax.set_ylabel("Cumulative Profit ($)")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
    fig.tight_layout()
    out_path = ROOT / "comparison_cumprofit.png"
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"Comparison chart saved: {out_path}")


if __name__ == "__main__":
    for key in BRANCHES:
        process_branch(key)
    draw_comparison_chart()
    print("All reports and charts generated.")
